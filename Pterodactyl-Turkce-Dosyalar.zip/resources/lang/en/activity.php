<?php

return [
    'auth' => [
        'fail' => 'Giriş başarısız',
        'success' => 'Giriş yapıldı',
        'password-reset' => 'Şifre sıfırlama',
        'reset-password' => 'Şifre sıfırlama isteği',
        'checkpoint' => 'İki faktörlü kimlik doğrulama isteği',
        'recovery-token' => 'İki faktörlü kurtarma jetonu kullanıldı',
        'token' => 'İki faktörlü zorluğu çözüldü',
        'ip-blocked' => 'İstenmeyen IP adresinden gelen istek engellendi: :identifier',
        'sftp' => [
            'fail' => 'SFTP girişi başarısız',
        ],
    ],
    'user' => [
        'account' => [
            'email-changed' => 'E-posta adresi değiştirildi: :old ile :new arasında',
            'password-changed' => 'Şifre değiştirildi',
        ],
        'api-key' => [
            'create' => 'Yeni API anahtarı oluşturuldu: :identifier',
            'delete' => 'API anahtarı silindi: :identifier',
        ],
        'ssh-key' => [
            'create' => 'SSH anahtarı hesaba eklendi: :fingerprint',
            'delete' => 'SSH anahtarı hesaptan kaldırıldı: :fingerprint',
        ],
        'two-factor' => [
            'create' => 'İki faktörlü kimlik doğrulama etkinleştirildi',
            'delete' => 'İki faktörlü kimlik doğrulama devre dışı bırakıldı',
        ],
    ],
    'server' => [
        'reinstall' => 'Sunucu yeniden yüklendi',
        'console' => [
            'command' => 'Sunucuda ":command" komutu çalıştırıldı',
        ],
        'power' => [
            'start' => 'Sunucu başlatıldı',
            'stop' => 'Sunucu durduruldu',
            'restart' => 'Sunucu yeniden başlatıldı',
            'kill' => 'Sunucu süreci sonlandırıldı',
        ],
        'backup' => [
            'download' => ':name yedeği indirildi',
            'delete' => ':name yedeği silindi',
            'restore' => ':name yedeği geri yüklendi (silinen dosyalar: :truncate)',
            'restore-complete' => ':name yedeği geri yükleme tamamlandı',
            'restore-failed' => ':name yedeği geri yükleme başarısız oldu',
            'start' => 'Yeni bir :name yedeği başlatıldı',
            'complete' => ':name yedeği tamamlandı olarak işaretlendi',
            'fail' => ':name yedeği başarısız olarak işaretlendi',
            'lock' => ':name yedeği kilitlendi',
            'unlock' => ':name yedeği kilidi kaldırıldı',
        ],
        'database' => [
            'create' => 'Yeni veritabanı oluşturuldu: :name',
            'rotate-password' => 'Veritabanı şifresi döndürüldü: :name',
            'delete' => 'Veritabanı silindi: :name',
        ],
        'file' => [
            'compress_one' => ':directory:file sıkıştırıldı',
            'compress_other' => ':directory içindeki :count dosya sıkıştırıldı',
            'read' => ':file içeriği görüntülendi',
            'copy' => ':file kopyası oluşturuldu',
            'create-directory' => ':directory adında bir dizin oluşturuldu',
            'decompress' => ':directory içindeki :files dosya açıldı',
            'delete_one' => ':directory:files.0 silindi',
            'delete_other' => ':directory içindeki :count dosya silindi',
            'download' => ':file indirildi',
            'pull' => ':url adresinden :directory içine uzaktan bir dosya indirildi',
            'rename_one' => ':directory:files.0.from, :directory:files.0.to olarak yeniden adlandırıldı',
            'rename_other' => ':directory içindeki :count dosya yeniden adlandırıldı',
            'write' => ':file içeriği değiştirildi',
            'upload' => 'Dosya yükleme işlemi başlatıldı',
            'uploaded' => ':directory:file yüklendi',
        ],
        'sftp' => [
            'denied' => 'İzinler nedeniyle SFTP erişimi engellendi',
            'create_one' => ':files.0 oluşturuldu',
            'create_other' => ':count yeni dosya oluşturuldu',
            'write_one' => ':files.0 içeriği değiştirildi',
            'write_other' => ':count dosya içeriği değiştirildi',
            'delete_one' => ':files.0 silindi',
            'delete_other' => ':count dosya silindi',
            'create-directory_one' => ':files.0 dizini oluşturuldu',
            'create-directory_other' => ':count dizin oluşturuldu',
            'rename_one' => ':files.0.from, :files.0.to olarak yeniden adlandırıldı',
            'rename_other' => ':count dosya yeniden adlandırıldı veya taşındı',
        ],
        'allocation' => [
            'create' => ':allocation sunucuya eklendi',
            'notes' => ':allocation için notlar güncellendi: ":old" den ":new"',
            'primary' => ':allocation, birincil sunucu tahsisi olarak ayarlandı',
            'delete' => ':allocation tahsis silindi',
        ],
        'schedule' => [
            'create' => ':name zamanlaması oluşturuldu',
            'update' => ':name zamanlaması güncellendi',
            'execute' => ':name zamanlaması manuel olarak çalıştırıldı',
            'delete' => ':name zamanlaması silindi',
        ],
        'task' => [
            'create' => ':name zamanlaması için yeni ":action" görev oluşturuldu',
            'update' => ':name zamanlaması için ":action" görevi güncellendi',
            'delete' => ':name zamanlaması için bir görev silindi',
        ],
        'settings' => [
            'rename' => 'Sunucunun adı değiştirildi: :old den :new',
            'description' => 'Sunucu açıklaması değiştirildi: :old den :new',
        ],
        'startup' => [
            'edit' => ':variable değişkeni :old den :new olarak değiştirildi',
            'image' => 'Sunucu Docker Görüntüsü güncellendi: :old den :new',
        ],
        'subuser' => [
            'create' => ':email alt kullanıcı olarak eklendi',
            'update' => ':email alt kullanıcı izinleri güncellendi',
            'delete' => ':email alt kullanıcı olarak kaldırıldı',
        ],
    ],
];
