<?php

return [
    'notices' => [
        'created' => 'Yeni bir yuva, :name, başarıyla oluşturuldu.',
        'deleted' => 'Panel üzerinden istenen yuvayı başarıyla sildiniz.',
        'updated' => 'Yuva yapılandırma seçenekleri başarıyla güncellendi.',
    ],
    'eggs' => [
        'notices' => [
            'imported' => 'Bu Egg ve ilişkili değişkenleri başarıyla içe aktarıldı.',
            'updated_via_import' => 'Bu Egg, sağlanan dosya kullanılarak güncellendi.',
            'deleted' => 'Panel üzerinden istenen egg başarıyla silindi.',
            'updated' => 'Egg yapılandırması başarıyla güncellendi.',
            'script_updated' => 'Egg yükleme betiği güncellendi ve sunucular kurulduğunda çalışacaktır.',
            'egg_created' => 'Yeni bir egg başarıyla oluşturuldu. Bu yeni eggi uygulamak için çalışan daemonları yeniden başlatmanız gerekebilir.',
        ],
    ],
    'variables' => [
        'notices' => [
            'variable_deleted' => ':variable değişkeni silindi ve sunucular yeniden oluşturulduğunda artık kullanılamayacak.',
            'variable_updated' => ':variable değişkeni güncellendi. Değişiklikleri uygulamak için bu değişkeni kullanan sunucuları yeniden oluşturmanız gerekecek.',
            'variable_created' => 'Yeni değişken başarıyla oluşturuldu ve bu egge atandı.',
        ],
    ],
];
