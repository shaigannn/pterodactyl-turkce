<?php

return [
    'validation' => [
        'fqdn_not_resolvable' => 'Sağlanan FQDN veya IP adresi geçerli bir IP adresine çözümlenemiyor.',
        'fqdn_required_for_ssl' => 'Bu düğüm için SSL kullanabilmek için genel bir IP adresine çözümlenen tam bir alan adına ihtiyaç duyulmaktadır.',
    ],
    'notices' => [
        'allocations_added' => 'Bu düğüme başarıyla tahsisler eklendi.',
        'node_deleted' => 'Düğüm panel üzerinden başarıyla kaldırıldı.',
        'location_required' => 'Bu panele bir düğüm ekleyebilmek için en az bir konum yapılandırmalısınız.',
        'node_created' => 'Yeni düğüm başarıyla oluşturuldu. Bu makine üzerinde daemon\'ı otomatik olarak yapılandırmak için \'Yapılandırma\' sekmesini ziyaret edebilirsiniz. <strong>Herhangi bir sunucu ekleyebilmek için en az bir IP adresi ve port tahsis etmelisiniz.</strong>',
        'node_updated' => 'Düğüm bilgileri güncellendi. Eğer herhangi bir daemon ayarı değiştirildiyse, bu değişikliklerin etkili olması için daemon\'ı yeniden başlatmanız gerekecektir.',
        'unallocated_deleted' => '<code>:ip</code> için tahsis edilmemiş tüm portlar silindi.',
    ],
];
