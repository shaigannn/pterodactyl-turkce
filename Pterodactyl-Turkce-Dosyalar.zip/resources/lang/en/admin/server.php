<?php

return [
    'exceptions' => [
        'no_new_default_allocation' => 'Bu sunucunun varsayılan tahsisini silmeye çalışıyorsunuz, ancak kullanılabilecek başka bir tahsis yok.',
        'marked_as_failed' => 'Bu sunucu, önceki bir kurulumun başarısız olduğu şeklinde işaretlendi. Bu durumda mevcut durumu değiştiremezsiniz.',
        'bad_variable' => ':name değişkeninde doğrulama hatası oluştu.',
        'daemon_exception' => 'Daemon ile iletişim kurma girişiminde bir istisna oluştu ve HTTP/:code yanıt kodu ile sonuçlandı. Bu istisna kaydedildi. (istek kimliği: :request_id)',
        'default_allocation_not_found' => 'İstenen varsayılan tahsis bu sunucunun tahsislerinde bulunamadı.',
    ],
    'alerts' => [
        'startup_changed' => 'Bu sunucunun başlangıç yapılandırması güncellendi. Eğer bu sunucunun yuvası veya egg\'si değiştirildiyse, şu anda bir yeniden yükleme gerçekleşecektir.',
        'server_deleted' => 'Sunucu sistemden başarıyla silindi.',
        'server_created' => 'Sunucu panelde başarıyla oluşturuldu. Daemon\'ın bu sunucuyu tamamen kurması için lütfen birkaç dakika bekleyin.',
        'build_updated' => 'Bu sunucunun yapı ayrıntıları güncellendi. Bazı değişikliklerin etkili olması için bir yeniden başlatma gerekebilir.',
        'suspension_toggled' => 'Sunucu askıya alma durumu :status olarak değiştirildi.',
        'rebuild_on_boot' => 'Bu sunucu, bir Docker Konteyner yeniden kurulumunu gerektirdiği şeklinde işaretlendi. Bu, sunucu bir sonraki başladığında gerçekleşecektir.',
        'install_toggled' => 'Bu sunucunun kurulum durumu değiştirildi.',
        'server_reinstalled' => 'Bu sunucu şu anda bir yeniden kurulum için sıraya alındı.',
        'details_updated' => 'Sunucu ayrıntıları başarıyla güncellendi.',
        'docker_image_updated' => 'Bu sunucu için varsayılan Docker imajı başarıyla değiştirildi. Bu değişikliği uygulamak için bir yeniden başlatma gereklidir.',
        'node_required' => 'Bu panele bir sunucu ekleyebilmek için en az bir düğüm yapılandırmalısınız.',
        'transfer_nodes_required' => 'Sunucuları transfer edebilmek için en az iki düğüm yapılandırmalısınız.',
        'transfer_started' => 'Sunucu transfer işlemi başlatıldı.',
        'transfer_not_viable' => 'Seçtiğiniz düğüm, bu sunucuyu barındırmak için gerekli disk alanına veya belleğe sahip değil.',
    ],
];
