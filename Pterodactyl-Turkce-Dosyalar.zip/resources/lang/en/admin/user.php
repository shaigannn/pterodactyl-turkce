<?php

return [
    'exceptions' => [
        'user_has_servers' => 'Hesabına bağlı aktif sunucuları olan bir kullanıcıyı silemezsiniz. Devam etmeden önce sunucularını silin.',
    ],
    'notices' => [
        'account_created' => 'Hesap başarıyla oluşturuldu.',
        'account_updated' => 'Hesap başarıyla güncellendi.',
    ],
];
