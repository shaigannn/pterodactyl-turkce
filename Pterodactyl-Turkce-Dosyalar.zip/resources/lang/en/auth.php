<?php

return [
    'sign_in' => 'Giriş Yap',
    'go_to_login' => 'Giriş Yapma Sayfasına Git',
    'failed' => 'Bu kimlik bilgilerine sahip bir hesap bulunamadı.',

    'forgot_password' => [
        'label' => 'Şifremi Unuttum',
        'label_help' => 'Şifrenizi sıfırlama talimatları almak için hesap e-posta adresinizi girin.',
        'button' => 'Hesabı Kurtar',
    ],

    'reset_password' => [
        'button' => 'Sıfırla ve Giriş Yap',
    ],

    'two_factor' => [
        'label' => '2-Faktör Kimlik',
        'label_help' => 'Bu hesap devam etmek için ikinci bir kimlik doğrulama katmanına ihtiyaç duyar. Lütfen girişi tamamlamak için cihazınız tarafından oluşturulan kodu girin.',
        'checkpoint_failed' => 'İki faktörlü kimlik doğrulama jetonu geçersizdi.',
    ],

    'throttle' => 'Çok fazla giriş denemesi yapıldı. Lütfen :seconds saniye sonra tekrar deneyin.',
    'password_requirements' => 'Şifre en az 8 karakter uzunluğunda olmalı ve bu site için benzersiz olmalıdır.',
    '2fa_must_be_enabled' => 'Yönetici, Panel kullanmak için hesabınızda 2-Faktör Kimlik Doğrulamanın etkinleştirilmesini şart koştu.',
];
