<?php

return [
    'location' => [
        'no_location_found' => 'Sağlanan kısa kodla eşleşen bir kayıt bulunamadı.',
        'ask_short' => 'Konum Kısa Kodu',
        'ask_long' => 'Konum Açıklaması',
        'created' => 'Yeni bir konum (:name) başarıyla oluşturuldu, ID: :id.',
        'deleted' => 'İstenen konum başarıyla silindi.',
    ],
    'user' => [
        'search_users' => 'Bir Kullanıcı Adı, Kullanıcı ID\'si veya E-posta Adresi Girin',
        'select_search_user' => 'Silinecek kullanıcının ID\'si (Yeniden aramak için \'0\' girin)',
        'deleted' => 'Kullanıcı başarıyla panelden silindi.',
        'confirm_delete' => 'Bu kullanıcıyı Panel\'den silmek istediğinizden emin misiniz?',
        'no_users_found' => 'Verilen arama terimi için kullanıcı bulunamadı.',
        'multiple_found' => 'Kullanıcı için birden fazla hesap bulundu, --no-interaction bayrağı nedeniyle bir kullanıcıyı silemiyorum.',
        'ask_admin' => 'Bu kullanıcı bir yönetici mi?',
        'ask_email' => 'E-posta Adresi',
        'ask_username' => 'Kullanıcı Adı',
        'ask_name_first' => 'Ad',
        'ask_name_last' => 'Soyad',
        'ask_password' => 'Parola',
        'ask_password_tip' => 'Eğer kullanıcıya e-posta ile gönderilecek rastgele bir parola ile hesap oluşturmak istiyorsanız, bu komutu tekrar çalıştırın (CTRL+C) ve `--no-password` bayrağını ekleyin.',
        'ask_password_help' => 'Parolalar en az 8 karakter uzunluğunda olmalı ve en az bir büyük harf ve sayı içermelidir.',
        '2fa_help_text' => [
            'Bu komut, kullanıcının hesabında etkinse 2 faktörlü kimlik doğrulamayı devre dışı bırakacaktır. Bu, kullanıcının hesabına erişiminin kilitlendiği bir hesap kurtarma komutu olarak yalnızca kullanılmalıdır.',
            'Eğer bunu yapmak istediğiniz değilse, işlemi sonlandırmak için CTRL+C tuşlarına basın.',
        ],
        '2fa_disabled' => ':email için 2-Faktör kimlik doğrulama devre dışı bırakıldı.',
    ],
    'schedule' => [
        'output_line' => 'İlk görev için `:schedule` (#:hash) için işlem başlatılıyor.',
    ],
    'maintenance' => [
        'deleting_service_backup' => 'Hizmet yedek dosyası :file siliniyor.',
    ],
    'server' => [
        'rebuild_failed' => '":name" (#:id) sunucusu ":node" düğümünde hata ile yeniden oluşturulamadı: :message',
        'reinstall' => [
            'failed' => '":name" (#:id) sunucusu ":node" düğümünde hata ile yeniden kurulamadı: :message',
            'confirm' => 'Bir grup sunucu için yeniden kurulum yapmak üzeresiniz. Devam etmek istiyor musunuz?',
        ],
        'power' => [
            'confirm' => ':count sunucu üzerinde bir :action işlemi gerçekleştirmek üzeresiniz. Devam etmek istiyor musunuz?',
            'action_failed' => '":name" (#:id) sunucusu ":node" düğümünde hata ile güç eylemi gerçekleştirilemedi: :message',
        ],
    ],
    'environment' => [
        'mail' => [
            'ask_smtp_host' => 'SMTP Sunucusu (örneğin smtp.gmail.com)',
            'ask_smtp_port' => 'SMTP Portu',
            'ask_smtp_username' => 'SMTP Kullanıcı Adı',
            'ask_smtp_password' => 'SMTP Parolası',
            'ask_mailgun_domain' => 'Mailgun Alan Adı',
            'ask_mailgun_endpoint' => 'Mailgun Uç Noktası',
            'ask_mailgun_secret' => 'Mailgun Gizli Anahtarı',
            'ask_mandrill_secret' => 'Mandrill Gizli Anahtarı',
            'ask_postmark_username' => 'Postmark API Anahtarı',
            'ask_driver' => 'E-postaları göndermek için hangi sürücü kullanılmalıdır?',
            'ask_mail_from' => 'E-postaların kaynaklandığı e-posta adresi',
            'ask_mail_name' => 'E-postaların görünen adı',
            'ask_encryption' => 'Kullanılacak şifreleme yöntemi',
        ],
    ],
];
