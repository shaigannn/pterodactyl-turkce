<?php

return [
    'email' => [
        'title' => 'E-postanızı Güncelleyin',
        'updated' => 'E-posta adresiniz güncellendi.',
    ],
    'password' => [
        'title' => 'Parolanızı Değiştirin',
        'requirements' => 'Yeni parolanız en az 8 karakter uzunluğunda olmalıdır.',
        'updated' => 'Parolanız güncellendi.',
    ],
    'two_factor' => [
        'button' => '2-Faktör Kimlik Doğrulamayı Yapılandır',
        'disabled' => 'Hesabınızdan iki faktörlü kimlik doğrulama devre dışı bırakıldı. Artık giriş yaparken bir belirteç sağlamanız istenmeyecek.',
        'enabled' => 'Hesabınıza iki faktörlü kimlik doğrulama etkinleştirildi! Bundan sonra giriş yaparken cihazınız tarafından oluşturulan kodu girmeniz gerekecek.',
        'invalid' => 'Sağlanan belirteç geçersizdi.',
        'setup' => [
            'title' => 'İki Faktörlü Kimlik Doğrulamayı Kur',
            'help' => 'Kodu tarayamıyor musunuz? Aşağıdaki kodu uygulamanıza girin:',
            'field' => 'Belirteci Girin',
        ],
        'disable' => [
            'title' => 'İki Faktörlü Kimlik Doğrulamayı Devre Dışı Bırak',
            'field' => 'Belirteci Girin',
        ],
    ],
];
