<?php

return [
    'search' => 'Sunucuları ara...',
    'no_matches' => 'Sağlanan arama kriterlerine uyan sunucu bulunamadı.',
    'cpu_title' => 'CPU',
    'memory_title' => 'Bellek',
];
