<?php

return [
    'daemon_connection_failed' => 'Daemon ile iletişim kurmaya çalışılırken HTTP/:code yanıt kodunu içeren bir istisna oluştu. Bu istisna kaydedildi.',
    'node' => [
        'servers_attached' => 'Bir düğümün silinebilmesi için ona bağlı hiç sunucu olmamalıdır.',
        'daemon_off_config_updated' => 'Daemon konfigürasyonu <strong>güncellendi</strong>, ancak konfigürasyon dosyasını (config.yml) Daemon üzerinde otomatik olarak güncelleme girişiminde bir hata oluştu. Bu değişiklikleri uygulamak için Daemon için konfigürasyon dosyasını manuel olarak güncellemeniz gerekecek.',
    ],
    'allocations' => [
        'server_using' => 'Bu tahsise şu anda bir sunucu atanmış durumda. Bir tahsis yalnızca hiçbir sunucu atanmamışsa silinebilir.',
        'too_many_ports' => 'Bir seferde tek bir aralıkta 1000den fazla port eklemek desteklenmez.',
        'invalid_mapping' => ':port için sağlanan eşleme geçersizdi ve işlenemedi.',
        'cidr_out_of_range' => 'CIDR notasyonu yalnızca /25 ile /32 arasındaki maskeleri destekler.',
        'port_out_of_range' => 'Bir tahsis içindeki portlar 1024 den büyük ve 65535 e eşit veya küçük olmalıdır.',
    ],
    'nest' => [
        'delete_has_servers' => 'Bu bağlı aktif sunuculara sahip Bir Yuva, Panel üzerinden silinemez.',
        'egg' => [
            'delete_has_servers' => 'Bu bağlı aktif sunuculara sahip Bir İmaj, Panel üzerinden silinemez.',
            'invalid_copy_id' => 'Bir betik kopyalamak için seçilen İmaj ya mevcut değil veya kendisi bir betik kopyalıyor.',
            'must_be_child' => 'Bu İmaj için Ayarları Kopyala yönergesi, seçilen Yuva için bir alt seçenek olmalıdır.',
            'has_children' => 'Bu İmaj, bir veya daha fazla diğer İmajının üst seviyesidir. Lütfen bu Yumurtaları silmeden önce bu Yumurtayı silin.',
        ],
        'variables' => [
            'env_not_unique' => ':name çevresel değişkeni bu Yumurta için benzersiz olmalıdır.',
            'reserved_name' => ':name çevresel değişkeni korumalıdır ve bir değişkene atanamaz.',
            'bad_validation_rule' => '":rule" doğrulama kuralı bu uygulama için geçerli bir kural değildir.',
        ],
        'importer' => [
            'json_error' => 'JSON dosyasını ayrıştırmaya çalışırken bir hata oluştu: :error.',
            'file_error' => 'Sağlanan JSON dosyası geçerli değildi.',
            'invalid_json_provided' => 'Sağlanan JSON dosyası tanımlanabilir bir formatta değil.',
        ],
    ],
    'subusers' => [
        'editing_self' => 'Kendi alt kullanıcı hesabınızı düzenlemek izin verilmez.',
        'user_is_owner' => 'Bu sunucunun sahibini alt kullanıcı olarak ekleyemezsiniz.',
        'subuser_exists' => 'Bu sunucu için zaten bu e-posta adresine sahip bir alt kullanıcı atanmış durumda.',
    ],
    'databases' => [
        'delete_has_databases' => 'Etkin veritabanlarına sahip olan bir veritabanı ana sunucuyu silemezsiniz.',
    ],
    'tasks' => [
        'chain_interval_too_long' => 'Zincirleme bir görevin maksimum aralık süresi 15 dakikadır.',
    ],
    'locations' => [
        'has_nodes' => 'Etkin düğümlere sahip olan bir konumu silemezsiniz.',
    ],
    'users' => [
        'node_revocation_failed' => '<a href=":link">Düğüm #:node</a> üzerinde anahtarları geri çekme başarısız oldu. :error',
    ],
    'deployment' => [
        'no_viable_nodes' => 'Otomatik dağıtım için belirtilen gereksinimleri karşılayan hiçbir düğüm bulunamadı.',
        'no_viable_allocations' => 'Otomatik dağıtım için gereksinimleri karşılayan hiçbir tahsis bulunamadı.',
    ],
    'api' => [
        'resource_not_found' => 'İstenen kaynak bu sunucuda mevcut değil.',
    ],
];
