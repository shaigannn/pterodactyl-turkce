import React from 'react';
import { ServerContext } from '@/state/server';
import ScreenBlock from '@/components/elements/ScreenBlock';
import ServerInstallSvg from '@/assets/images/server_installing.svg';
import ServerErrorSvg from '@/assets/images/server_error.svg';
import ServerRestoreSvg from '@/assets/images/server_restore.svg';

export default () => {
    const status = ServerContext.useStoreState((state) => state.server.data?.status || null);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data?.isTransferring || false);
    const isNodeUnderMaintenance = ServerContext.useStoreState(
        (state) => state.server.data?.isNodeUnderMaintenance || false
    );

    return status === 'installing' || status === 'install_failed' || status === 'reinstall_failed' ? (
        <ScreenBlock
            title={'Sunucunuz Kurulum Aşamasında'}
            image={ServerInstallSvg}
            message={'Sunucunuz en kısa sürede kurulacaktır. Lütfen birkaç dakika içerisinde tekrar kontrol ediniz.'}
        />
    ) : status === 'suspended' ? (
        <ScreenBlock
            title={'Sunucunuzun Fatura Süresi Gelmiştir.'}
            image={ServerErrorSvg}
            message={'Sunucunuza faturanızı ödemediğinizden dolayı erişemezsiniz. Lütfen faturayı ödedikten sonra tekrar deneyiniz.'}
        />
    ) : isNodeUnderMaintenance ? (
        <ScreenBlock
            title={'Sunucularımız Şu Anda Bakımda!'}
            image={ServerErrorSvg}
            message={'Sunucunuzun barındırılmış olduğu ana sunucu şu anda bakımda. Lütfen birkaç saat sonra tekrar deneyiniz. Eğer bizlerle iletişime geçmek isterseniz Discord sunucumuza katılabilirsiniz.'}
        />
    ) : (
        <ScreenBlock
            title={isTransferring ? 'Sunucu Transfer Ediliyor' : 'Sunucu Yedeği Kuruluyor'}
            image={ServerRestoreSvg}
            message={
                isTransferring
                    ? 'Sunucunuz başka bir makineye taşınıyor. Lütfen daha sonra tekrar deneyiniz.'
                    : 'Şu anda sunucunuzun en son alınmış yedeği kuruluyor. Lütfen daha sonra tekrar deneyiniz.'
            }
        />
    );
};
