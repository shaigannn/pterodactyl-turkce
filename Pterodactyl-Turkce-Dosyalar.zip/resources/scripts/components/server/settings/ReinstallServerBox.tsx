import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import reinstallServer from '@/api/server/reinstallServer';
import { Actions, useStoreActions } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { httpErrorToHuman } from '@/api/http';
import tw from 'twin.macro';
import { Button } from '@/components/elements/button/index';
import { Dialog } from '@/components/elements/dialog';

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const [modalVisible, setModalVisible] = useState(false);
    const { addFlash, clearFlashes } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const reinstall = () => {
        clearFlashes('settings');
        reinstallServer(uuid)
            .then(() => {
                addFlash({
                    key: 'settings',
                    type: 'success',
                    message: 'Sunucunuzun yeniden kurulumu başlatılmıştır. En kısa sürede sunucunuz tekrar kurulacaktır.',
                });
            })
            .catch((error) => {
                console.error(error);

                addFlash({ key: 'settings', type: 'error', message: httpErrorToHuman(error) });
            })
            .then(() => setModalVisible(false));
    };

    useEffect(() => {
        clearFlashes();
    }, []);

    return (
        <TitledGreyBox title={'Sunucuyu Yeniden Kurma'} css={tw`relative`}>
            <Dialog.Confirm
                open={modalVisible}
                title={'Sunucu Yeniden Kurulumu'}
                confirm={'Evet, Yeniden Kur'}
                onClose={() => setModalVisible(false)}
                onConfirmed={reinstall}
            >
                Sunucunuz durdurulacaktır ve birkaç dosya silinebilir. Onaylıyor musunuz?
            </Dialog.Confirm>
            <p css={tw`text-sm`}>
                Lütfen sunucunuzu yeniden kurmadan önce veri kaybı yaşayabileceğinizden, sunucunuzun durdurulacağından emin olarak bu işlemi gerçekleştiriniz.
            </p>
            <div css={tw`mt-6 text-right`}>
                <Button.Danger variant={Button.Variants.Secondary} onClick={() => setModalVisible(true)}>
                    Sunucuyu Yeniden Kur
                </Button.Danger>
            </div>
        </TitledGreyBox>
    );
};
