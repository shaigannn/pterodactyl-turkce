@extends('layouts.admin')

@section('title')
    Database Hosts
@endsection

@section('content-header')
    <h1>Database Ayarları</h1>
@endsection

@section('content')
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Database Host Listesi</h3>
                <div class="box-tools">
                    <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#newHostModal">Yeni Host Oluştur</button>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th>ID</th>
                            <th>İsim</th>
                            <th>Host</th>
                            <th>Port</th>
                            <th>Kullanıcı Adı</th>
                            <th class="text-center">Veri Tabanları</th>
                            <th class="text-center">Node</th>
                        </tr>
                        @foreach ($hosts as $host)
                            <tr>
                                <td><code>{{ $host->id }}</code></td>
                                <td><a href="{{ route('admin.databases.view', $host->id) }}">{{ $host->name }}</a></td>
                                <td><code>{{ $host->host }}</code></td>
                                <td><code>{{ $host->port }}</code></td>
                                <td>{{ $host->username }}</td>
                                <td class="text-center">{{ $host->databases_count }}</td>
                                <td class="text-center">
                                    @if(! is_null($host->node))
                                        <a href="{{ route('admin.nodes.view', $host->node->id) }}">{{ $host->node->name }}</a>
                                    @else
                                        <span class="label label-default">Yok</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="newHostModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="{{ route('admin.databases') }}" method="POST">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Yeni Database Hostu Oluştur</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="pName" class="form-label">İsim</label>
                        <input type="text" name="name" id="pName" class="form-control" />
                        <p class="text-muted small">Diğer veri tabanlarından ayırmak için bir isim. Örneğin: <code>db.dilekhost.com.tr.</code>.</p>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="pHost" class="form-label">Host</label>
                            <input type="text" name="host" id="pHost" class="form-control" />
                            <p class="text-muted small">Veri tabanını barındırılacağı sunucunun IP adresi</p>
                        </div>
                        <div class="col-md-6">
                            <label for="pPort" class="form-label">Port</label>
                            <input type="text" name="port" id="pPort" class="form-control" value="3306"/>
                            <p class="text-muted small">Barındırma sunucusunda kurulmuş olan SQL Sunucusunun portu .</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="pUsername" class="form-label">Kullanıcı Adı</label>
                            <input type="text" name="username" id="pUsername" class="form-control" />
                            <p class="text-muted small">SQL sunucusuna bağlanmak için oluşturduğunuz kullanıcı adı.</p>
                        </div>
                        <div class="col-md-6">
                            <label for="pPassword" class="form-label">Şifre</label>
                            <input type="password" name="password" id="pPassword" class="form-control" />
                            <p class="text-muted small">SQL sunucusuna bağlanmak için oluşturduğunuz şifre.</p>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="pNodeId" class="form-label">Bağlı Olan Node</label>
                        <select name="node_id" id="pNodeId" class="form-control">
                            <option value="">Yok</option>
                            @foreach($locations as $location)
                                <optgroup label="{{ $location->short }}">
                                    @foreach($location->nodes as $node)
                                        <option value="{{ $node->id }}">{{ $node->name }}</option>
                                    @endforeach
                                </optgroup>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <p class="text-danger small text-left">Bu veritabanı ana bilgisayarı için tanımlanan hesabın <strong>mutlaka</strong> <code>WITH GRANT OPTION</code> izni olmalıdır. Belirtilen hesap bu izne sahip değilse, veritabanı oluşturma istekleri <em>başarısız olacaktır</em>. MySQL için bu panel için tanımladığınız aynı hesap bilgilerini <strong>kullanmayın.</strong></strong></p>
                    {!! csrf_field() !!}
                    <button type="button" class="btn btn-default btn-sm pull-left" data-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-success btn-sm">Oluştur</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('#pNodeId').select2();
    </script>
@endsection
