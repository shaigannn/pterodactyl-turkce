@extends('layouts.admin')

@section('title')
    Yeni Node - Pterodactyl
@endsection

@section('content-header')
    <h1>Yeni Node Olutur</h1>
@endsection

@section('content')
<form action="{{ route('admin.nodes.new') }}" method="POST">
    <div class="row">
        <div class="col-sm-6">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Temel Bilgiler</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="pName" class="form-label">İsim</label>
                        <input type="text" name="name" id="pName" class="form-control" value="{{ old('name') }}"/>
                    </div>
                    <div class="form-group">
                        <label for="pDescription" class="form-label">Açıklama</label>
                        <textarea name="description" id="pDescription" rows="4" class="form-control">{{ old('description') }}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="pLocationId" class="form-label">Lokasyon</label>
                        <select name="location_id" id="pLocationId">
                            @foreach($locations as $location)
                                <option value="{{ $location->id }}" {{ $location->id != old('location_id') ?: 'selected' }}>{{ $location->short }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Node Görünürlüğü</label>
                        <div>
                            <div class="radio radio-success radio-inline">

                                <input type="radio" id="pPublicTrue" value="1" name="public" checked>
                                <label for="pPublicTrue"> Herkese Açık </label>
                            </div>
                            <div class="radio radio-danger radio-inline">
                                <input type="radio" id="pPublicFalse" value="0" name="public">
                                <label for="pPublicFalse"> Gizlik </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="pFQDN" class="form-label">FQDN</label>
                        <input type="text" name="fqdn" id="pFQDN" class="form-control" value="{{ old('fqdn') }}"/>
                        <p class="text-muted small">Lütfen, node ile bağlantı için kullanılacak alan adını girin (örneğin <code>node.example.com</code>). Eğer bu node için SSL kullanmıyorsanız, bir IP adresi <em>sadece</em> kullanılabilir.</p>
                    </div>
                    <div class="form-group">
                        <label class="form-label">SSL Üzerinden İletişim</label>
                        <div>
                            <div class="radio radio-success radio-inline">
                                <input type="radio" id="pSSLTrue" value="https" name="scheme" checked>
                                <label for="pSSLTrue"> SSL Bağlantısı Kullan </label>
                            </div>
                            <div class="radio radio-danger radio-inline">
                                <input type="radio" id="pSSLFalse" value="http" name="scheme" @if(request()->isSecure()) disabled @endif>
                                <label for="pSSLFalse"> HTTP Bağlantısı Kullan </label>
                            </div>
                        </div>
                        @if(request()->isSecure())
                            <p class="text-danger small">Panel şu anda güvenli bir bağlantı kullanacak şekilde yapılandırılmış durumda. Tarayıcıların düğümünüze bağlanabilmesi için bir SSL bağlantısı <strong>mutlaka</strong> kullanılmalıdır.</p>
                        @else
                            <p class="text-muted small">Bir IP Adresi kullanıyorsanız veya hiç SSL kullanmak istemiyorsanız, HTTP bağlantısını seçin.</p>
                        @endif
                    </div>
                    <div class="form-group">
                        <label class="form-label">Proxy Ayarları</label>
                        <div>
                            <div class="radio radio-success radio-inline">
                                <input type="radio" id="pProxyFalse" value="0" name="behind_proxy" checked>
                                <label for="pProxyFalse"> Proxy Kullanılmıyor </label>
                            </div>
                            <div class="radio radio-info radio-inline">
                                <input type="radio" id="pProxyTrue" value="1" name="behind_proxy">
                                <label for="pProxyTrue"> Proxy Kullanılıyor </label>
                            </div>
                        </div>
                        <p class="text-muted small">Eğer paneliniz Cloudflare vb. bir filtreden geçiyorsa lüt</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Donanım Ayarları</h3>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="pDaemonBase" class="form-label">Sunucu Dosyaların</label>
                            <input type="text" name="daemonBase" id="pDaemonBase" class="form-control" value="/var/lib/pterodactyl/volumes" />
                            <p class="text-muted small">Sunucu dosyalarının depolanması gereken dizini girin. <strong>Eğer OVH kullanıyorsanız, bölüm düzeninizi kontrol etmelisiniz. Yeterli alanınızın olması için <code>/home/daemon-data</code> kullanmanız gerekebilir.</strong></p>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="pMemory" class="form-label">Toplam RAM Miktarı</label>
                            <div class="input-group">
                                <input type="text" name="memory" data-multiplicator="true" class="form-control" id="pMemory" value="{{ old('memory') }}"/>
                                <span class="input-group-addon">MB</span>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="pMemoryOverallocate" class="form-label">Bellek Sınırı Aşımı</label>
                            <div class="input-group">
                                <input type="text" name="memory_overallocate" class="form-control" id="pMemoryOverallocate" value="{{ old('memory_overallocate') }}"/>
                                <span class="input-group-addon">%</span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <p class="text-muted small">Yeni sunucular için kullanılabilir toplam bellek miktarını girin. Bellek aşırı tahsisine izin vermek istiyorsanız, izin vermek istediğiniz yüzdeyi girin. Bellek aşırı tahsis kontrolünü devre dışı bırakmak için alanı <code>-1</code> olarak girin. <code>0</code> girmek, düğümü sınırların üzerine çıkaracak yeni sunucular oluşturmayı önleyecektir.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="pDisk" class="form-label">Toplam Disk Alanı</label>
                            <div class="input-group">
                                <input type="text" name="disk" data-multiplicator="true" class="form-control" id="pDisk" value="{{ old('disk') }}"/>
                                <span class="input-group-addon">MB</span>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="pDiskOverallocate" class="form-label">Disk Sınırı Aşımı</label>
                            <div class="input-group">
                                <input type="text" name="disk_overallocate" class="form-control" id="pDiskOverallocate" value="{{ old('disk_overallocate') }}"/>
                                <span class="input-group-addon">%</span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <p class="text-muted small">Yeni sunucular için kullanılabilir toplam disk alanını girin. Disk alanı aşırı tahsisine izin vermek istiyorsanız, izin vermek istediğiniz yüzdeyi girin. Aşırı tahsis kontrolünü devre dışı bırakmak için alanı <code>-1</code> olarak girin. <code>0</code> girmek, node sınırların üzerine çıkaracak yeni sunucular oluşturmayı önleyecektir.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="pDaemonListen" class="form-label">Daemon Port</label>
                            <input type="text" name="daemonListen" class="form-control" id="pDaemonListen" value="8080" />
                        </div>
                        <div class="form-group col-md-6">
                            <label for="pDaemonSFTP" class="form-label">Daemon SFTP Port</label>
                            <input type="text" name="daemonSFTP" class="form-control" id="pDaemonSFTP" value="2022" />
                        </div>
                        <div class="col-md-12">
                            <p class="text-muted small">Eğer cloudflare kullanıyorsanız Daemon Portunu <code><strong>8443</strong></code> olarak ayarlamalısınız.</p>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    {!! csrf_field() !!}
                    <button type="submit" class="btn btn-success pull-right">Node Oluştur</button>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('#pLocationId').select2();
    </script>
@endsection
