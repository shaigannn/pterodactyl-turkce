@extends('layouts.admin')

@section('title')
    {{ $node->name }}: Configuration
@endsection

@section('content-header')
    <h1>{{ $node->name }}</h1>
@endsection


@section('content')
<div class="row">
    <div class="col-xs-12">
        <div class="nav-tabs-custom nav-tabs-floating">
            <ul class="nav nav-tabs">
                <li><a href="{{ route('admin.nodes.view', $node->id) }}">Bilgi</a></li>
                <li><a href="{{ route('admin.nodes.view.settings', $node->id) }}">Ayarlar</a></li>
                <li class="active"><a href="{{ route('admin.nodes.view.configuration', $node->id) }}">Config</a></li>
                <li><a href="{{ route('admin.nodes.view.allocation', $node->id) }}">Port Yönlendirme</a></li>
                <li><a href="{{ route('admin.nodes.view.servers', $node->id) }}">Sunucular</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-8">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Config Dosyası</h3>
            </div>
            <div class="box-body">
                <pre class="no-margin">{{ $node->getYamlConfiguration() }}</pre>
            </div>
            <div class="box-footer">
                <p class="no-margin">Bu dosya, daemon'ın kök dizinine (genellikle <code>/etc/pterodactyl</code>) <code>config.yml</code> adında bir dosya içine yerleştirilmelidir.</p>
            </div>
        </div>
    </div>
    <div class="col-sm-4">
        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title">Otomatik Config</h3>
            </div>
            <div class="box-body">
                <p class="text-muted small">
                    Otomatik config yazdırmak için lütfen aşağıdaki butona tıklayınız. Size verilen kodu <strong>SSH</strong> ile bağlandığınız sunucuya yazınız.
                </p>
            </div>
            <div class="box-footer">
                <button type="button" id="configTokenBtn" class="btn btn-sm btn-default" style="width:100%;">Komut Oluştur</button>
            </div>
        </div>
    </div>
</div>
@endsection

@section('footer-scripts')
    @parent
    <script>
    $('#configTokenBtn').on('click', function (event) {
        $.ajax({
            method: 'POST',
            url: '{{ route('admin.nodes.view.configuration.token', $node->id) }}',
            headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
        }).done(function (data) {
            swal({
                type: 'success',
                title: 'Komut Oluşturuldu.',
                text: '<p>Aşşağıda verilen kodu sunucunuza yazınız:<br /><small><pre>cd /etc/pterodactyl && sudo wings configure --panel-url {{ config('app.url') }} --token ' + data.token + ' --node ' + data.node + '{{ config('app.debug') ? ' --allow-insecure' : '' }}</pre></small></p>',
                html: true
            })
        }).fail(function () {
            swal({
                title: 'Hata',
                text: 'Otomatik kurulum kodu oluşturulamadı.',
                type: 'error'
            });
        });
    });
    </script>
@endsection
